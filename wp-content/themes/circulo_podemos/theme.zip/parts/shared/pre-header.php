<aside id="pre_header">
	<div class="container">
		<a class="logo-podemos" title="Web de partido Podemos" href="http://podemos.info/"><img src="http://podemos.info/wordpress/wp-content/themes/podemos/images/header/podemos-logo.png" alt="Podemos"></a>
		<nav class="enlaces-podemos" role="navigation" itemscope itemtype="http://schema.org/SiteNavigationElement">
			<ul>
				<li><a target="_blank" href="http://podemos.info/asambleaciudadana/" title="Asamblea Ciudadana">Asamblea Ciudadana</a></li>
				<li><a target="_blank" href="http://podemos.info/cuentas-claras/" title="Cuentas claras">Cuentas claras</a></li>
				<li><a target="_blank" href="http://www.reddit.com/r/podemos/" title="Plaza Podemos">Plaza Podemos</a></li>
				<li><a target="_blank" href="http://podemos.info/programa/" title="Programa">Programa</a></li>
				<li><a target="_blank" href="http://podemos.info/como-nos-financiamos/" title="Financiación">Financiación</a></li>
			</ul>
		</nav>
		<nav class="rrss-podemos">
			<ul>
				<li><a class="icon twitter" target="_blank" href="https://twitter.com/ahorapodemos" title="Perfil de Twitter de Podemos"></a></li>
				<li><a class="icon facebook" target="_blank" href="https://www.facebook.com/pages/Podemos/269212336568846" title="Página de Facebook de Podemos"></a></li>
				<li><a class="icon youtube" target="_blank" href="https://www.youtube.com/channel/UCtK7s89RJ9X9Nv9EQCMu9Lg" title="Canal de Youtube de Podemos"></a></li>
			</ul>
		</nav>
	</div>
</aside>
