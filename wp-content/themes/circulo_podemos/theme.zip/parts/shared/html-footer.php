
	<?php wp_footer(); ?>
  <script src="<?php echo get_stylesheet_directory_uri(); ?>/js/waypoints.min.js"></script>
	<script type="text/javascript">

	</script>
	</body>
</html>