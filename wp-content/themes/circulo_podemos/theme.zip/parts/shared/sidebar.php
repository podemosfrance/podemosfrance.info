<aside id="sidebar">
	<?php if (! dynamic_sidebar('primary-widget-area')) { ?>

	<?php } ?>
</aside>
